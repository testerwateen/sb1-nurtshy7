import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { ChevronRight, User, Mail, Lock, Calendar, MapPin } from 'lucide-react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { Link } from 'expo-router';

export default function ProfileScreen() {
  const isDarkMode = useSelector((state: RootState) => state.theme.isDarkMode);

  // Dynamic styles based on isDarkMode
  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#121212' : '#ffffff',
    },
    title: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    profileCard: {
      backgroundColor: isDarkMode ? '#1e1e1e' : '#f3f4f6',
    },
    profileText: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    sectionTitle: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    menuLabel: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
  };

  return (
    <ScrollView style={[styles.container, dynamicStyles.container]}>
      <View style={styles.header}>
        <Text style={[styles.title, dynamicStyles.title]}>Profile</Text>
      </View>

      <View style={[styles.profileCard, dynamicStyles.profileCard]}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg' }}
          style={styles.profileImage}
        />
        <Text style={[styles.profileName, dynamicStyles.profileText]}>John Doe</Text>
        <Text style={[styles.profileEmail, dynamicStyles.profileText]}>john.doe@example.com</Text>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Account Details</Text>
        <Link href="app/pages/profile/edit-profile" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <User size={20} color="#666" />
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Edit Profile</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
        <Link href="change-email" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <Mail size={20} color="#666" />
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Change Email</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
        <Link href="change-password" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <Lock size={20} color="#666" />
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Change Password</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Personal Information</Text>
        <Link href="date-of-birth" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <Calendar size={20} color="#666" />
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Date of Birth</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
        <Link href="location" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <MapPin size={20} color="#666" />
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Location</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 20,
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  header: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  profileCard: {
    margin: 20,
    padding: 20,
    backgroundColor: '#2a2a2a',
    borderRadius: 16,
    alignItems: 'center',
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 16,
  },
  profileName: {
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 16,
    color: '#666',
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  menuLabel: {
    fontSize: 16,
    color: '#fff',
    marginLeft: 12,
    flex: 1,
  },
});