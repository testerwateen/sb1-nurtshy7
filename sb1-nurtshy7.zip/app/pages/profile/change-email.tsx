import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import React from 'react';

export default function ChangeEmailScreen() {
  const isDarkMode = useSelector((state: RootState) => state.theme.isDarkMode);
  const [email, setEmail] = React.useState('john.doe@example.com');

  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#121212' : '#ffffff',
    },
    input: {
      backgroundColor: isDarkMode ? '#1e1e1e' : '#f3f4f6',
      color: isDarkMode ? '#ffffff' : '#000000',
    },
  };

  return (
    <View style={[styles.container, dynamicStyles.container]}>
      <TextInput
        style={[styles.input, dynamicStyles.input]}
        value={email}
        onChangeText={setEmail}
        placeholder="Email Address"
        keyboardType="email-address"
      />
      <TouchableOpacity style={styles.saveButton}>
        <Text style={styles.saveButtonText}>Update Email</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  input: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#22c55e',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});