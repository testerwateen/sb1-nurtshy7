import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';

export default function ChangePasswordScreen() {
  const isDarkMode = useSelector((state: RootState) => state.theme.isDarkMode);
  const [currentPassword, setCurrentPassword] = React.useState('');
  const [newPassword, setNewPassword] = React.useState('');

  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#121212' : '#ffffff',
    },
    input: {
      backgroundColor: isDarkMode ? '#1e1e1e' : '#f3f4f6',
      color: isDarkMode ? '#ffffff' : '#000000',
    },
  };

  return (
    <View style={[styles.container, dynamicStyles.container]}>
      <TextInput
        style={[styles.input, dynamicStyles.input]}
        value={currentPassword}
        onChangeText={setCurrentPassword}
        placeholder="Current Password"
        secureTextEntry
      />
      <TextInput
        style={[styles.input, dynamicStyles.input]}
        value={newPassword}
        onChangeText={setNewPassword}
        placeholder="New Password"
        secureTextEntry
      />
      <TouchableOpacity style={styles.saveButton}>
        <Text style={styles.saveButtonText}>Change Password</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  input: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#22c55e',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});