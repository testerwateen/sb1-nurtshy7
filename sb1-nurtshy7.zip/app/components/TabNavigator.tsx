import { Tabs } from 'expo-router';
import { Dumbbell, MessageSquare, Camera, Settings, Home } from 'lucide-react-native';
import { useSelector } from 'react-redux';
import { RootState } from '../store';

export default function TabNavigator() {
  const isDarkMode = useSelector((state: RootState) => state.theme.isDarkMode);

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor: isDarkMode ? '#1a1a1a' : '#fff',
          borderTopWidth: 1,
          borderTopColor: isDarkMode ? '#333' : '#e5e5e5',
        },
        tabBarActiveTintColor: '#22c55e',
        tabBarInactiveTintColor: isDarkMode ? '#888' : '#666',
        headerStyle: {
          backgroundColor: isDarkMode ? '#1a1a1a' : '#fff',
        },
        headerTitleStyle: {
          color: isDarkMode ? '#fff' : '#000',
          fontWeight: '600',
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="workouts"
        options={{
          title: 'Workouts',
          tabBarIcon: ({ color, size }) => <Dumbbell size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="coach"
        options={{
          title: 'AI Coach',
          tabBarIcon: ({ color, size }) => <MessageSquare size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="nutrition"
        options={{
          title: 'Nutrition',
          tabBarIcon: ({ color, size }) => <Camera size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
        }}
      />
    </Tabs>
  );
}