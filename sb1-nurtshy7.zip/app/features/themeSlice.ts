import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ThemeState {
  isDarkMode: boolean;
}

const initialState: ThemeState = {
  isDarkMode:true,
};

const themeSlice = createSlice({
  name: 'theme',
  initialState,
  reducers: {
    setTheme: (state, action: PayloadAction<boolean>) => {
      state.isDarkMode = action.payload;
      AsyncStorage.setItem('isDarkMode', JSON.stringify(action.payload))
        .then(() => console.log('Theme saved:', action.payload))
        .catch((err) => console.error('Failed to save theme:', err));
    },
    toggleTheme: (state) => {
      state.isDarkMode = !state.isDarkMode;
      AsyncStorage.setItem('isDarkMode', JSON.stringify(state.isDarkMode))
        .then(() => console.log('Theme toggled and saved:', state.isDarkMode))
        .catch((err) => console.error('Failed to save theme:', err));
    },
  },
});

export const loadThemeFromStorage = () => async (dispatch: any) => {
  try {
    const value = await AsyncStorage.getItem('isDarkMode');
    if (value !== null) {
      const parsedValue = JSON.parse(value);
      console.log('Theme loaded:', parsedValue);
      dispatch(setTheme(parsedValue));
    } else {
      console.log('No theme found in storage, using default:', initialState.isDarkMode);
    }
  } catch (err) {
    console.error('Failed to load theme:', err);
  }
};

export const { toggleTheme, setTheme } = themeSlice.actions;

export default themeSlice.reducer;