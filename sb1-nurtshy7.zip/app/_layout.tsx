import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { Provider, useDispatch } from 'react-redux';
import store from './store';
import { loadThemeFromStorage } from './features/themeSlice';

function ThemeLoader() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(loadThemeFromStorage());
  }, [dispatch]);

  return null;
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <Provider store={store}>
      <ThemeLoader />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="auto" />
    </Provider>
  );
}
