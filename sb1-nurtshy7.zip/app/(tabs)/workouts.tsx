import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Link } from 'expo-router';
// Add these imports:
import { useLayoutEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import { RootState } from '../store';

const workouts = [
  {
    id: '1',
    title: 'Full Body Strength',
    duration: '45 min',
    level: 'Intermediate',
    image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg',
  },
  {
    id: '2',
    title: 'HIIT Cardio',
    duration: '30 min',
    level: 'Advanced',
    image: 'https://images.pexels.com/photos/3775566/pexels-photo-3775566.jpeg',
  },
  {
    id: '3',
    title: 'Yoga Flow',
    duration: '60 min',
    level: 'Beginner',
    image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg',
  },
];

export default function WorkoutsScreen() {
  const navigation = useNavigation();
  const isDarkMode = useSelector((state:RootState) => state.theme.isDarkMode);

  useLayoutEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  // Dynamic styles based on isDarkMode
  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#1a1a1a' : '#fff',
    },
    title: {
      color: isDarkMode ? '#fff' : '#000',
    },
    subtitle: {
      color: isDarkMode ? '#aaa' : '#666',
    },
    categoryButton: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#e5e7eb',
    },
    categoryText: {
      color: isDarkMode ? '#fff' : '#000',
    },
    workoutCard: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6',
    },
    workoutTitle: {
      color: isDarkMode ? '#fff' : '#000',
    },
    workoutMeta: {
      color: isDarkMode ? '#aaa' : '#666',
    },
  };

  return (
    <ScrollView style={[styles.container, dynamicStyles.container]}>
      <View style={styles.header}>
        <Text style={[styles.title, dynamicStyles.title]}>Workouts</Text>
        <Text style={[styles.subtitle, dynamicStyles.subtitle]}>Choose your workout</Text>
      </View>

      <View style={styles.categories}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {['All', 'Strength', 'Cardio', 'Yoga', 'HIIT'].map((category) => (
            <TouchableOpacity key={category} style={[styles.categoryButton, dynamicStyles.categoryButton]}>
              <Text style={[styles.categoryText, dynamicStyles.categoryText]}>{category}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <View style={styles.workoutsList}>
        {workouts.map((workout) => (
          <Link key={workout.id} href={`/workout/${workout.id}`} asChild>
            <TouchableOpacity style={[styles.workoutCard, dynamicStyles.workoutCard]}>
              <Image source={{ uri: workout.image }} style={styles.workoutImage} />
              <View style={styles.workoutContent}>
                <Text style={[styles.workoutTitle, dynamicStyles.workoutTitle]}>{workout.title}</Text>
                <Text style={[styles.workoutMeta, dynamicStyles.workoutMeta]}>
                  {workout.duration} • {workout.level}
                </Text>
              </View>
            </TouchableOpacity>
          </Link>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop:20,
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  header: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  categories: {
    paddingVertical: 16,
  },
  categoryButton: {
    backgroundColor: '#2a2a2a',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginHorizontal: 8,
  },
  categoryText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  workoutsList: {
    padding: 20,
  },
  workoutCard: {
    backgroundColor: '#2a2a2a',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
  },
  workoutImage: {
    width: '100%',
    height: 200,
  },
  workoutContent: {
    padding: 16,
  },
  workoutTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  workoutMeta: {
    fontSize: 14,
    color: '#666',
  },
});