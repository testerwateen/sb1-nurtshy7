import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';
import { useLayoutEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { Camera, BarChart3 } from 'lucide-react-native';
import { useSelector } from 'react-redux';

export default function NutritionScreen() {
  const navigation = useNavigation();
  const isDarkMode = useSelector((state) => state.theme.isDarkMode);

  useLayoutEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  // Dynamic styles based on isDarkMode
  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#1a1a1a' : '#fff',
    },
    title: {
      color: isDarkMode ? '#fff' : '#000',
    },
    subtitle: {
      color: isDarkMode ? '#aaa' : '#666',
    },
    captureCard: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#e5e7eb',
    },
    captureText: {
      color: isDarkMode ? '#fff' : '#000',
    },
    captureSubtext: {
      color: isDarkMode ? '#aaa' : '#666',
    },
    sectionTitle: {
      color: isDarkMode ? '#fff' : '#000',
    },
    mealCard: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6',
    },
    mealTitle: {
      color: isDarkMode ? '#fff' : '#000',
    },
    mealMeta: {
      color: isDarkMode ? '#aaa' : '#666',
    },
    nutritionCard: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6',
    },
    statCard: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6',
    },
    statNumber: {
      color: isDarkMode ? '#22c55e' : '#16a34a',
    },
    statLabel: {
      color: isDarkMode ? '#aaa' : '#666',
    },
  };

  return (
    <ScrollView style={[styles.container, dynamicStyles.container]}>
      <View style={styles.header}>
        <Text style={[styles.title, dynamicStyles.title]}>Nutrition</Text>
        <Text style={[styles.subtitle, dynamicStyles.subtitle]}>Track your meals and get AI insights</Text>
      </View>

      <TouchableOpacity style={[styles.captureCard, dynamicStyles.captureCard]}>
        <Camera size={32} color="#22c55e" />
        <Text style={[styles.captureText, dynamicStyles.captureText]}>Capture Meal</Text>
        <Text style={[styles.captureSubtext, dynamicStyles.captureSubtext]}>Get instant nutritional analysis</Text>
      </TouchableOpacity>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Today's Meals</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {[1, 2, 3].map((meal) => (
            <View key={meal} style={[styles.mealCard, dynamicStyles.mealCard]}>
              <Image
                source={{ uri: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg' }}
                style={styles.mealImage}
              />
              <View style={styles.mealContent}>
                <Text style={[styles.mealTitle, dynamicStyles.mealTitle]}>Healthy Breakfast {meal}</Text>
                <Text style={[styles.mealMeta, dynamicStyles.mealMeta]}>450 cal • 35g protein</Text>
              </View>
            </View>
          ))}
        </ScrollView>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Nutrition Analysis</Text>
          <BarChart3 size={24} color="#22c55e" />
        </View>
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, dynamicStyles.statCard]}>
            <Text style={[styles.statNumber, dynamicStyles.statNumber]}>1,850</Text>
            <Text style={[styles.statLabel, dynamicStyles.statLabel]}>Calories</Text>
          </View>
          <View style={[styles.statCard, dynamicStyles.statCard]}>
            <Text style={[styles.statNumber, dynamicStyles.statNumber]}>125g</Text>
            <Text style={[styles.statLabel, dynamicStyles.statLabel]}>Protein</Text>
          </View>
          <View style={[styles.statCard, dynamicStyles.statCard]}>
            <Text style={[styles.statNumber, dynamicStyles.statNumber]}>180g</Text>
            <Text style={[styles.statLabel, dynamicStyles.statLabel]}>Carbs</Text>
          </View>
          <View style={[styles.statCard, dynamicStyles.statCard]}>
            <Text style={[styles.statNumber, dynamicStyles.statNumber]}>65g</Text>
            <Text style={[styles.statLabel, dynamicStyles.statLabel]}>Fats</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop:20,
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  header: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  captureCard: {
    margin: 20,
    padding: 20,
    backgroundColor: '#2a2a2a',
    borderRadius: 16,
    alignItems: 'center',
  },
  captureText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginTop: 12,
  },
  captureSubtext: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  section: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  mealCard: {
    width: 240,
    backgroundColor: '#2a2a2a',
    borderRadius: 12,
    overflow: 'hidden',
    marginRight: 16,
  },
  mealImage: {
    width: '100%',
    height: 160,
  },
  mealContent: {
    padding: 12,
  },
  mealTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  mealMeta: {
    fontSize: 14,
    color: '#666',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#2a2a2a',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: '700',
    color: '#22c55e',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
  },
});