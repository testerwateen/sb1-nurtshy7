import TabNavigator from "../components/TabNavigator";



export default function () {
  return <TabNavigator />;
}