import { View, Text, StyleSheet, TextInput, ScrollView, TouchableOpacity } from 'react-native';
import { Send } from 'lucide-react-native';
import { useState, useLayoutEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { RootState } from '../store';

export default function CoachScreen() {
  const [message, setMessage] = useState('');
  const isDarkMode = useSelector((state:RootState) => state.theme.isDarkMode);
  const navigation = useNavigation();

  useLayoutEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  const messages = [
    { id: 1, text: "Hi! I'm your AI fitness coach. How can I help you today?", isAI: true },
    { id: 2, text: "I'd like to improve my squat form", isAI: false },
    {
      id: 3,
      text: "Great! Here are some key points for proper squat form:\n\n1. Keep your feet shoulder-width apart\n2. Point toes slightly outward\n3. Keep your chest up\n4. Push your hips back\n5. Keep your knees in line with your toes",
      isAI: true,
    },
  ];

  // Dynamic styles based on isDarkMode
  const dynamicStyles = {
    title: {
      color: isDarkMode ? '#ffffff' : '#000000',
      fontSize: 28,
      fontWeight: '700',
    },
    container: {
      backgroundColor: isDarkMode ? '#1a1a1a' : '#fff',
    },
    aiMessage: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#e5e7eb',
    },
    header: {
      padding: 20,
      paddingTop: 60,
    },
    userMessage: {
      backgroundColor: isDarkMode ? '#22c55e' : '#22c55e',
    },
    aiText: {
      color: isDarkMode ? '#fff' : '#000',
    },
    userText: {
      color: '#fff',
    },
    inputContainer: {
      backgroundColor: isDarkMode ? '#2a2a2a' : '#f3f4f6',
    },
    input: {
      backgroundColor: isDarkMode ? '#333' : '#e5e7eb',
      color: isDarkMode ? '#fff' : '#000',
    },
    sendButton: {
      backgroundColor: isDarkMode ? '#333' : '#22c55e',
    },
  };

  return (
    <View style={[styles.container, dynamicStyles.container]}>
      <View style={dynamicStyles.header}>
        <Text style={[{ color: isDarkMode ? '#ffffff' : '#000000', fontSize: 28, fontWeight: '700' as const }]}>AI Coach</Text>
      </View>
      <ScrollView style={styles.messagesContainer}>
        {messages.map((msg) => (
          <View
            key={msg.id}
            style={[
              styles.messageBox,
              msg.isAI ? [styles.aiMessage, dynamicStyles.aiMessage] : [styles.userMessage, dynamicStyles.userMessage],
            ]}>
            <Text style={[styles.messageText, msg.isAI ? [styles.aiText, dynamicStyles.aiText] : [styles.userText, dynamicStyles.userText]]}>
              {msg.text}
            </Text>
          </View>
        ))}
      </ScrollView>

      <View style={[styles.inputContainer, dynamicStyles.inputContainer]}>
        <TextInput
          style={[styles.input, dynamicStyles.input]}
          placeholder="Ask your AI coach..."
          placeholderTextColor={isDarkMode ? "#888" : "#666"}
          value={message}
          onChangeText={setMessage}
          multiline
        />
        <TouchableOpacity style={[styles.sendButton, dynamicStyles.sendButton]}>
          <Send size={24} color={isDarkMode ? "#22c55e" : "#fff"} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  messagesContainer: {
    flex: 1,
    padding: 16,
  },
  messageBox: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 16,
    marginBottom: 12,
  },
  aiMessage: {
    backgroundColor: '#2a2a2a',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 4,
  },
  userMessage: {
    backgroundColor: '#22c55e',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 4,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
  },
  aiText: {
    color: '#fff',
  },
  userText: {
    color: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#2a2a2a',
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    backgroundColor: '#333',
    borderRadius: 20,
    padding: 12,
    color: '#fff',
    fontSize: 16,
    maxHeight: 100,
    marginRight: 12,
  },
  sendButton: {
    width: 48,
    height: 48,
    backgroundColor: '#333',
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
});