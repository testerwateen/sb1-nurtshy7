import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { ChevronRight, Crown } from 'lucide-react-native';
// Add these imports:
import { useLayoutEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { toggleTheme } from '../features/themeSlice';
import { RootState } from '../store';
import { Link } from 'expo-router';

export default function SettingsScreen() {
  const dispatch = useDispatch();
  const isDarkMode = useSelector((state:RootState) => state.theme.isDarkMode);
  const navigation = useNavigation();

  useLayoutEffect(() => {
    navigation.setOptions({ headerShown: false });
  }, [navigation]);

  // Dynamic styles based on isDarkMode
  const dynamicStyles = {
    container: {
      backgroundColor: isDarkMode ? '#121212' : '#ffffff',
    },
    title: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    subscriptionCard: {
      backgroundColor: isDarkMode ? '#1e1e1e' : '#f3f4f6',
    },
    subscriptionTitle: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    subscriptionDescription: {
      color: isDarkMode ? '#d1d5db' : '#4b5563',
    },
    sectionTitle: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    settingLabel: {
      color: isDarkMode? '#ffffff' : '#000000',
    },
    menuLabel: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
    logoutButton: {
      backgroundColor: isDarkMode ? '#1e1e1e' : '#f3f4f6',
    },
    logoutText: {
      color: isDarkMode ? '#ffffff' : '#000000',
    },
  };

  return (
    <ScrollView style={[styles.container, dynamicStyles.container]}>
      <View style={styles.header}>
        <Text style={[styles.title, dynamicStyles.title]}>Settings</Text>
      </View>
      <TouchableOpacity style={[styles.subscriptionCard, dynamicStyles.subscriptionCard]}>
        <View style={styles.subscriptionContent}>
          <Crown size={24} color="#fbbf24" />
          <View style={styles.subscriptionText}>
            <Text style={[styles.subscriptionTitle, dynamicStyles.subscriptionTitle]}>Premium Membership</Text>
            <Text style={[styles.subscriptionDescription, dynamicStyles.subscriptionDescription]}>
              Get unlimited access to all features
            </Text>
          </View>
        </View>
        <ChevronRight size={24} color="#666" />
      </TouchableOpacity>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Preferences</Text>
        <View style={styles.settingItem}>
        <Text style={[styles.settingLabel, dynamicStyles.sectionTitle]}>Dark Mode</Text>
          <Switch value={isDarkMode} onValueChange={() => dispatch(toggleTheme())} />
        </View>
        <View style={styles.settingItem}>
        <Text style={[styles.settingLabel, dynamicStyles.sectionTitle]}>Notifications</Text>
          <Switch />
        </View>
        <View style={styles.settingItem}>
        <Text style={[styles.settingLabel, dynamicStyles.sectionTitle]}>Workout Reminders</Text>
          <Switch />
        </View>
      </View>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Account</Text>
        <Link href="../pages/profile" asChild>
          <TouchableOpacity style={styles.menuItem}>
            <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Profile Settings</Text>
            <ChevronRight size={20} color="#666" />
          </TouchableOpacity>
        </Link>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Payment Methods</Text>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Subscription</Text>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>
      </View>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, dynamicStyles.sectionTitle]}>Support</Text>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Help Center</Text>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Privacy Policy</Text>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={[styles.menuLabel, dynamicStyles.menuLabel]}>Terms of Service</Text>
          <ChevronRight size={20} color="#666" />
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={[styles.logoutButton, dynamicStyles.logoutButton]}>
        <Text style={[styles.logoutText, dynamicStyles.logoutText]}>Log Out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 20,
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  header: {
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  subscriptionCard: {
    margin: 20,
    padding: 20,
    backgroundColor: '#2a2a2a',
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  subscriptionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subscriptionText: {
    marginLeft: 12,
  },
  subscriptionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  subscriptionDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 16,
  },
  settingItem: {
        color: '#fff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingLabel: {
    color: '#ffffff',
    fontSize: 16,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  menuLabel: {
    fontSize: 16,
    color: '#fff',
  },
  logoutButton: {
    margin: 20,
    padding: 16,
    backgroundColor: '#dc2626',
    borderRadius: 12,
    alignItems: 'center',
  },
  logoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});